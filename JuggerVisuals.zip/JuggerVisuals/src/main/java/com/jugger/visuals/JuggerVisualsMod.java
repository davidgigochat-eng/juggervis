package com.jugger.visuals;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Vec3d;

/**
 * Jugger Visuals
 * Чисто косметический PvP-мод: частицы при ударе игрока и яркий эффект при килле.
 * Никакого ESP / x-ray / aimbot — только то, что и так видно в обычной игре.
 */
public class JuggerVisualsMod implements ModInitializer {

    @Override
    public void onInitialize() {
        // Срабатывает после того, как удар уже применился (включая блок щитом)
        ServerLivingEntityEvents.AFTER_DAMAGE.register((entity, source, baseDamageTaken, damageTaken, blocked) -> {
            if (blocked) return;
            if (!(source.getAttacker() instanceof PlayerEntity)) return;
            spawnHitEffect(entity);
        });

        // Срабатывает в момент смерти существа
        ServerLivingEntityEvents.AFTER_DEATH.register(this::onDeath);
    }

    private void onDeath(LivingEntity entity, DamageSource source) {
        if (!(source.getAttacker() instanceof PlayerEntity)) return;
        spawnKillEffect(entity);
    }

    /** Частицы + звук в момент удара по существу. */
    private void spawnHitEffect(LivingEntity entity) {
        if (!(entity.getWorld() instanceof ServerWorld world)) return;
        Vec3d pos = entity.getPos().add(0, entity.getHeight() * 0.5, 0);

        world.spawnParticles(ParticleTypes.CRIT, pos.x, pos.y, pos.z, 14, 0.3, 0.35, 0.3, 0.05);
        world.spawnParticles(ParticleTypes.DAMAGE_INDICATOR, pos.x, pos.y, pos.z, 6, 0.25, 0.3, 0.25, 0.1);

        world.playSound(null, entity.getBlockPos(),
                SoundEvents.ENTITY_PLAYER_ATTACK_STRONG, SoundCategory.PLAYERS, 0.6f, 1.3f);
    }

    /** Яркая вспышка частиц + звук в момент килла. */
    private void spawnKillEffect(LivingEntity entity) {
        if (!(entity.getWorld() instanceof ServerWorld world)) return;
        Vec3d pos = entity.getPos().add(0, entity.getHeight() * 0.5, 0);

        world.spawnParticles(ParticleTypes.TOTEM_OF_UNDYING, pos.x, pos.y, pos.z, 50, 0.5, 0.6, 0.5, 0.35);
        world.spawnParticles(ParticleTypes.END_ROD, pos.x, pos.y, pos.z, 25, 0.4, 0.5, 0.4, 0.12);
        world.spawnParticles(ParticleTypes.EXPLOSION, pos.x, pos.y, pos.z, 1, 0.0, 0.0, 0.0, 0.0);

        world.playSound(null, entity.getBlockPos(),
                SoundEvents.ENTITY_PLAYER_LEVELUP, SoundCategory.PLAYERS, 1.0f, 1.4f);
    }
}
