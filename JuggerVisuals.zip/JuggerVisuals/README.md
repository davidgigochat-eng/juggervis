# Jugger Visuals (Fabric 1.21.4)

Косметический PvP-мод: частицы при ударе и яркий эффект при убийстве.
Никакого ESP / x-ray / aimbot — мод не показывает ничего, что не видно в обычной игре.

## Что внутри
- `src/main/java/com/jugger/visuals/JuggerVisualsMod.java` — вся логика (через официальные события Fabric API `ServerLivingEntityEvents`).
- `fabric.mod.json` — манифест мода.
- `build.gradle`, `settings.gradle`, `gradle.properties` — сборочный скаффолд под Fabric Loom.

## Как собрать

1. Установи JDK 21.
2. У меня нет доступа в интернет, поэтому я не смог сгенерировать `gradlew`/`gradle-wrapper.jar` (он качается с сервера Gradle). Сделай один из вариантов:
   - **Проще всего:** открой папку проекта в IntelliJ IDEA с плагином Gradle — IDE сама подтянет обёртку и зависимости, дальше просто `Build` → `Build Artifacts`, либо запусти Gradle-таск `build` из панели Gradle.
   - **Через консоль:** если у тебя уже стоит Gradle, зайди в папку проекта и выполни `gradle wrapper`, затем `./gradlew build` (или `gradlew.bat build` на Windows).
3. Готовый `.jar` появится в `build/libs/jugger-visuals-1.0.0.jar`.
4. Закинь его в папку `mods` клиента/сервера с установленным **Fabric Loader** и **Fabric API** для 1.21.4.

## Если Gradle ругается на версии

Версии в `gradle.properties` (`loader_version`, `yarn_mappings`, `fabric_version`) актуальны на момент написания, но Fabric обновляется часто и точную свежую цифру я без интернета проверить не могу. Если сборка падает с ошибкой "не найдена версия" — зайди на https://fabricmc.net/develop/template/, выбери Loader и Minecraft 1.21.4, сгенерируй чистый проект (там версии всегда актуальные и гарантированно рабочие) и просто перенеси в него файл `JuggerVisualsMod.java` и блок `depends` из `fabric.mod.json` — остальное совпадёт.

## Настройка эффектов

Все параметры частиц/звука — прямо в `JuggerVisualsMod.java`, в методах `spawnHitEffect` и `spawnKillEffect`. Можно менять типы частиц (`ParticleTypes.*`), количество, разброс и звуки (`SoundEvents.*`) под свой вкус.
